require 'mercadopago_sdk'

Mercadopago::SDK.configure do |config|
  config.access_token = ENV['MERCADO_PAGO_ACCESS_TOKEN']
end
